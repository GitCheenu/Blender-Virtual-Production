# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# cv2, pathlib, platform need to be installed in python library

bl_info = {
    "name": "LIVEVideosCapture",
    "author": "Srinivas Katta",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Panel",
    "description": "Capture Live videos from webcam",
    "warning": "W.I.P",
    "category": "Camera"
}

import bpy
import os

import cv2

from bpy.types import Panel, Operator
from bpy.props import (
    StringProperty,
    BoolProperty,
    EnumProperty,
    FloatProperty,
    CollectionProperty,
)
import time
from bpy.types import WindowManager 

from pathlib import Path
from platform import system

#Windows_path = '~\\AppData\\Roaming\\Blender Foundation\\Blender\\2.91\\scripts\\addons\\'
#Unix_path = '$HOME/.config/blender/2.91/'
#Mac_path = '/Users/$USER/Library/Application Support/Blender/2.91/'

import addon_utils
addon_paths =addon_utils.paths()

#default_path = ''
if system() == 'Linux': 
    # Default Location
    default_path  = str(Path.home()) + "/Videos/"
    slash = '/'
else:
    print (system())
    default_path  = str(Path.home()) + "\Videos\\"    
    slash = '\\'
    
print(bpy.path.native_pathsep(default_path))
os.chdir(default_path)
print (system())
pic = ''
frames = '0'
test_pattern = addon_paths[1] + slash + 'color-checker.png'
actor = "Actor"
preview_collections = {}
width=0
height=0

#---------------------------------------------#
def accum_enum(self,context):
    #To populate enum with shots from selected directory
    wm = context.window_manager
    
    l = wm.clip_dir
    p,d,f = next(os.walk(l))
    o = 1
    i_item=[]
    if not d == "":
        for i in d:
            i_item += (i, i, '', o),
            o += 1    
    else:
        i_item = 0
    
    return i_item

#---------------------------------------------#
def previews_images(self, context):
    """EnumProperty callback"""
    scene = context.scene
    live_tool = scene.live_tool

    global frames
    global pic
    enum_items = []
    thumb = None

    if context is None:
        return enum_items

    VALID_EXTENSIONS = ('.png', '.jpg', '.jpeg','.mp4','.avi', '.mkv')

    wm = context.window_manager
    directory = wm.clip_dir + wm.shot_enum
    #Find no.of frames in a slected shot
    frames = len([x for x in list(os.scandir(directory)) if x.is_file()])

    # Get the preview collection (defined in register func).
    pcoll = preview_collections["main"]

    if directory == pcoll.clip_dir:
        return pcoll.clip_previews

#    print("Scanning directory: %s" % directory)

    if directory and os.path.exists(directory):
        # Scan the directory for png/jpg files
        image_paths = []
        for fn in os.listdir(directory):
            if fn.lower().endswith(VALID_EXTENSIONS):
                image_paths.append(fn)

        for i, name in enumerate(image_paths):
            # generates a thumbnail preview for a file.
            filepath = os.path.join(directory, name)
            icon = pcoll.get(name)
            if not icon:
                thumb = pcoll.load(name, filepath, 'IMAGE')
            else:
                thumb = pcoll[name]
            enum_items.append((name, name, "", thumb.icon_id, i))

    pcoll.clip_previews = sorted(enum_items)
    pcoll.clip_dir = directory
    pic = wm.clip_previews
    
    return pcoll.clip_previews


#---------------------------------------------#
def ConvertImageSeq(self, context):
    # Load image seuence into Texture Node/MovieClip
    # and set frame length
    
    scene = bpy.context.scene
    live_tool = scene.live_tool
    wm = context.window_manager
    mat = bpy.data.materials

    p,d,f = next(os.walk(os.getcwd()))

#    f = len([x for x in list(os.scandir( os.getcwd() ) ) if x.is_file()])
    
    firstframe_path = live_tool.clip_location + self.actor + slash + self.actor +'_0.png'

    mat[self.actor].node_tree.nodes['Image Texture'].select = True
    mat[self.actor].node_tree.nodes['Image Texture'].image = bpy.data.images.load(filepath = firstframe_path)
    mat[self.actor].node_tree.nodes['Image Texture'].show_texture = True
    mat[self.actor].node_tree.nodes['Image Texture'].image.source = 'SEQUENCE'
    mat[self.actor].node_tree.nodes['Image Texture'].image_user.use_auto_refresh = True
    mat[self.actor].node_tree.nodes['Image Texture'].image_user.frame_duration = len(f)-1
    scene.frame_end = len(f)-1
    
    # If 
    bpy.data.movieclips.load(filepath = firstframe_path)
    
    bpy.ops.collection.objects_add_active()
            
#---------------------------------------------# 
def Delete_Clip(self, context):
    # Delete a recorded Clip/Shot or when RECORD/TAKE not selected

    scene = context.scene
    live_tool = scene.live_tool
    wm = context.window_manager
    
    VALID_EXTENSIONS = ('.png', '.jpg', '.jpeg','.mp4','.avi', '.mkv','.mov')

    obj = wm.shot_enum
    path = wm.clip_dir + wm.shot_enum
    os.chdir(path)
    
    if os.listdir(path):
        self.report({'INFO'}, 'Deleting Clip...')
        os.chmod(path, 0o777) 
        for f in os.listdir(path):
            if f in VALID_EXTENSIONS:
                os.remove(f)
            else:
                pass
        os.chdir(slash+'..')
        os.rmdir(path)
    else:
        os.chdir(slash+'..')
        os.rmdir(path)

    if bpy.context.active_object == obj :
        bpy.data.objects.remove(obj)
        
    for o in list(bpy.data.objects):
        if  o.name == obj or  o.name == obj + '_0' :
            bpy.data.objects.remove(o)

    bpy.context.window_manager['shot_enum'] = 1 # Reset Shot List to first option

#-----------------------------------------------------#
def load_into_scene(self, context, image, clip=False, capture=False):
    # Create image plane with input image dimensions
    # Add Materials Node setup for ChromaKeying with Normal Node
    
    seq = context.area
    scene = context.scene
    live_tool = scene.live_tool
    wm = context.window_manager
    
    global width
    global height
    global frames
    
    VIDEO_EXTENSIONS = ('.mp4','.avi', '.mkv', '.mov')
    fr = frames
    path = wm.clip_dir + wm.shot_enum + slash
    if not capture:
        actor, ext = (os.path.splitext(wm.clip_previews))
        if ext in VIDEO_EXTENSIONS: # for video files
            #Get image dimensions width, height, frames/files, type
            im_cap = cv2.VideoCapture(path + image)
            fr = im_cap.get(7) # get frame count inaccurate? but fast!
            width = im_cap.get(3) 
            height = im_cap.get(4)
            im_cap.release()
            imagefrom = wm.clip_dir+wm.shot_enum+slash+wm.clip_previews
            live_tool.clip_location = wm.clip_dir
            live_tool.clip_name = wm.clip_previews
        else: # for sequencial files
            imagefrom = wm.clip_dir + wm.shot_enum + slash + str(image) 
            img = cv2.imread(imagefrom)
            height, width, _ = img.shape # image dimension
            live_tool.clip_name = actor

    else:
        actor = live_tool.clip_name+'_'+live_tool.take_no
        ext = ''        
        imagefrom =  str(image)
        wm.shot_enum = actor#live_tool.clip_name + '_' + live_tool.take_no
    
    frames = fr
    # Create plane for image
    bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=False, align='WORLD', location=(0, 0, height/100), scale=(width, height, 1))
    bpy.context.object.name = actor
    bpy.context.object.scale[0] = width/100
    bpy.context.object.scale[1] = height/100
    bpy.context.object.rotation_euler[0] = 1.5708 #Front Facing
    bpy.data.objects[actor].show_name = True
    this_scene = scene.name+ '_' +live_tool.clip_name
    
    # Create Collection   
    if bpy.context.scene.collection.children.find(this_scene) == -1:
        coll = bpy.data.collections.new(this_scene)
        bpy.context.scene.collection.children.link(coll)
        bpy.ops.object.collection_link(collection=this_scene)
    else:
        bpy.ops.object.collection_link(collection=this_scene)

    o = bpy.context.active_object
    bpy.context.collection.objects.unlink(o)
    
    # Material Creation
    for mat in list(bpy.data.materials):
        # Check if material exist and create/modal
        if mat.name == actor:
            bpy.data.materials.remove(bpy.data.materials[mat.name])
 
    material_basic = bpy.data.materials.new(name = actor) # Need check for duplicate ie .001
    material_basic.use_nodes = True
    material_basic.blend_method = 'CLIP' # for viewport
    material_basic.shadow_method = 'CLIP'
    material_basic.alpha_threshold = 0.0
    
    principled_node = material_basic.node_tree.nodes.get('Principled BSDF')
    principled_node.inputs[5].default_value = 0.0 # Spec
    principled_node.inputs[7].default_value = 0.0 # Roughness
    principled_node.inputs[19].default_value = 1 # Alpha
    

    bpy.data.images.new(actor,width,height)
    tex_node = material_basic.node_tree.nodes.new('ShaderNodeTexImage')
    tex_node.location = (-1000, 250)
    tex_node.show_texture = True
            
    gamma_node = material_basic.node_tree.nodes.new('ShaderNodeGamma')
    gamma_node.location = (-700, 250)
    gamma_node.inputs[1].default_value = 1.8

    link = material_basic.node_tree.links.new

    if clip:
        normal_node = material_basic.node_tree.nodes.new('ShaderNodeNormal')
        normal_node.location = (-500, -150)
        normal_node.outputs[0].default_value = [0.828796, 0.500405, -0.250386]
        
        colorRamp_node = material_basic.node_tree.nodes.new('ShaderNodeValToRGB')
        colorRamp_node.location = (-300, -150)
        colorRamp_node.color_ramp.interpolation = 'B_SPLINE'       
        colorRamp_node.color_ramp.elements[1].position = 0.4
        
        material_basic.alpha_threshold = 0.5
        
        link(gamma_node.outputs[0], normal_node.inputs[0])
        link(normal_node.outputs[1], colorRamp_node.inputs[0])
        link(colorRamp_node.outputs[0], principled_node.inputs[19])
        
    link(tex_node.outputs[0], gamma_node.inputs[0])
    #link(tex_node.outputs[0], principled_node.inputs[19])
    link(gamma_node.outputs[0], principled_node.inputs[0])
    link(gamma_node.outputs[0], principled_node.inputs[17])

    bpy.context.object.active_material = material_basic
    bpy.context.space_data.shading.color_type = 'TEXTURE'
    bpy.context.space_data.shading.show_specular_highlight = False

    bpy.data.materials[actor].node_tree.nodes['Image Texture'].select = True
    bpy.data.materials[actor].node_tree.nodes['Image Texture'].image = bpy.data.images.load(imagefrom)
    bpy.data.materials[actor].node_tree.nodes['Image Texture'].show_texture = True
    
    if clip:
        if ext in VIDEO_EXTENSIONS:
               (bpy.data.materials[actor].node_tree.nodes['Image Texture'].image).source = 'MOVIE'
        else:
            (bpy.data.materials[actor].node_tree.nodes['Image Texture'].image).source = 'SEQUENCE'
            
        bpy.data.materials[actor].node_tree.nodes['Image Texture'].image_user.use_auto_refresh = True
        bpy.data.materials[actor].node_tree.nodes['Image Texture'].image_user.frame_duration = frames
        scene.frame_end = frames
        bpy.data.movieclips.load(filepath = imagefrom)

    
#---------------------------------------------#
class LIVE_Properties(bpy.types.PropertyGroup):
    
    clip_name : bpy.props.StringProperty(
                                        name= "ActorName ", 
                                        description="",  
                                        default= 'Actor'
                                        )
    take_no : bpy.props.StringProperty(
                                        name= "Take No ",  
                                        default= "Take_1"
                                        )
    clip_location : bpy.props.StringProperty(
                                            name= "Project",  
                                            description="Folder",  
                                            default=default_path
                                            )

    message = bpy.props.StringProperty(
                                        name = "message",
                                        description = "message",
                                        default = ''
                                    )    

    rec_camera = bpy.props.BoolProperty(name= "rec", description = "Record this Take")          
                               

#---------------------------------------------#
class LIVE_PT_main_panel(Panel):
    bl_label = "LIVE CAMERA"
    bl_idname = "LIVE_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Live"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        live_tool = scene.live_tool
        wm = context.window_manager
   
        row = layout.row()
        row.prop(wm, "clip_dir")

        layout.prop(wm, "shot_enum")
        row = layout.row()
        row.template_icon_view(wm, "clip_previews") #627

        layout.label(text="Frames in this shot is : " + str(frames))
        layout.label(text="Picture is : " + str(pic))

        row = layout.row()
        row.scale_y = 1
        row.operator("clipto.scene_operator", text="Clip to Scene",icon = 'SEQUENCE') 
        row.operator("pic_to.scene_operator",text="Pic to Scene", icon = 'SEQUENCE')            
    
        row = layout.row()
        row.scale_y = 1
        row.operator("delete.clip_operator", icon = 'SEQUENCE')            
        
        layout.scale_y = 1.5
    
        row = layout.row()
        row.scale_y = 2
        row.operator("live.camera_operator", text="Go LIVE", icon = 'VIEW_CAMERA')

        layout.prop(live_tool, "rec_camera", text="RECORD / TAKE")


#---------------------------------------------#
def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

#---------------------------------------------#    
class LIVE_OT_camera(bpy.types.Operator):
    """Go Live"""
    bl_label = "Going LIVE!"
    bl_idname = "live.camera_operator"

    # scene = bpy.context.scene

    mats = bpy.props.CollectionProperty(type=bpy.types.PropertyGroup)

    act_name : bpy.props.StringProperty(
                                        name = "ActorName ", 
                                        description ="",  
                                        default = 'Actor'
                                        )
    take : bpy.props.StringProperty(
                                        name = "Take No.", 
                                        description ="",  
                                        default = 'Take_1'
                                        )                                        
    message = bpy.props.StringProperty(
                                        name = "message",
                                        description = "message",
                                        default = ''
                                    ) 
    WindowManager.clip_dir = StringProperty(
        name="Clip Location",
        subtype='DIR_PATH',
        default=default_path
    )

    _timer = None
    cap  = None    
    frames = 0
    store_images = []
    
    def draw(self, context):
        scene = context.scene
        live_tool = scene.live_tool
        wm = context.window_manager
        
        
        layout = self.layout
        
        layout.label(text="Input Actor Name / Take Number...")
        layout.prop(live_tool, "clip_name")

        layout.prop(live_tool, "take_no")

        row=layout.row()
        row.prop(self, "wm.clip_dir")


        
    
    def invoke(self,context,event):
        
        return context.window_manager.invoke_props_dialog(self)#{'FINISHED'}
        
     #---------------------------------------------#    
    def execute(self, context):
        scene = context.scene
        live_tool = scene.live_tool
        wm = context.window_manager

        scene.frame_start = 0
        self.message = 'LIVE...'
        self.report({'INFO'}, self.message)
        live_tool.clip_location = wm.clip_dir
        self.actor = live_tool.clip_name + '_' + live_tool.take_no
        
        if live_tool.clip_location == '' or live_tool.clip_name == '' or live_tool.take_no == '':
            print ('Project/Clip/Take cannot be empty')
            return {'RUNNING_MODAL'}
        
        if not os.path.exists(live_tool.clip_location):
            os.mkdir(live_tool.clip_location)
            os.chdir(live_tool.clip_location)
            os.mkdir(self.actor)
            os.chdir(self.actor)
        else:
            os.chdir(live_tool.clip_location)
            if not os.path.exists(self.actor):
                os.mkdir(self.actor)
                os.chdir(self.actor)
            else:
                os.chdir(self.actor)
                self.report({'INFO'}, 'Take aleady exsists')
#                print (self.actor, 'Take aleady exsists')
                return {'RUNNING_MODAL'}

        self.init_camera()
        load_into_scene(self, context, test_pattern,  clip=True, capture=True)
        
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.001, window=context.window)
        wm.modal_handler_add(self)      

        return {'RUNNING_MODAL'}#{'FINISHED'}

#---------------------------------------------#
    def init_camera(self):
                
        global width
        global height
        self.report({'INFO'}, 'Camera initializing...')
        if self.cap == None:
            self.cap = cv2.VideoCapture(0)
            width = self.cap.get(3)*2
            height = self.cap.get(4)*1.5
            fps = self.cap.get(5)
      
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 60)

#            time.sleep(0.1)    

#---------------------------------------------#        
    def cancel(self, context):
        scene = bpy.context.scene
        live_tool = scene.live_tool
        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        
        global frames
#        scene.render.fps = 15
        i = 1
        firstframe_path = live_tool.clip_location + self.actor + slash + self.actor +'_' 
        self.report({'INFO'}, 'Writing to disk...') 
        if (live_tool.rec_camera):
#            ShowMessageBox("Writing to disk...") 
            for i, im in enumerate(self.store_images):
                cv2.imwrite((firstframe_path + str(i) + '.png') , im, [cv2.IMWRITE_PNG_COMPRESSION, 0])             
            ConvertImageSeq(self, context)
            bpy.data.images[self.actor].source = 'SEQUENCE'
        else:
            print('Deleting...')
            Delete_Clip(self,context )
   
        self.store_images.clear()
        self.cap.release()
        self.cap = None

#---------------------------------------------#    
    def modal(self, context, event):
        scene = bpy.context.scene
        live_tool = scene.live_tool
        global frames
    
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            bpy.data.images[self.actor].source = 'SEQUENCE' 
            self.cancel(context)
            
            return {'CANCELLED'}
        

        if event.type == 'TIMER':

            success, img = self.cap.read()
            if not success: 
                return {'FINISHED'}

            self.store_images.append(img)
            firstframe_path = live_tool.clip_location + self.actor + slash + self.actor +'_0.png' 
            cv2.imwrite(firstframe_path, img, [cv2.IMWRITE_PNG_COMPRESSION, 0])    # self.actor+"_%d.png" % self.frames,     

            bpy.data.materials[self.actor].node_tree.nodes['Image Texture'].image = bpy.data.images.load(firstframe_path)
            bpy.data.materials[self.actor].node_tree.nodes['Image Texture'].show_texture = True
            bpy.data.materials[self.actor].node_tree.nodes['Image Texture'].image_user.use_auto_refresh = True
            
            scene.frame_current = frames
                
        return {'PASS_THROUGH'}


#---------------------------------------------#
class LIVE_OT_DeleteClip(Operator):
    """Delete Shot"""
    bl_label = "Delete Shot"
    bl_idname = "delete.clip_operator"
    
    def draw(self, context):
        scene = context.scene
        live_tool = scene.live_tool
        wm = context.window_manager
        
        
        layout = self.layout
        
        layout.label(text = "DELETE " + wm.shot_enum + " from " + wm.clip_dir + " ?")

    
    def invoke(self,context,event):
        
        return context.window_manager.invoke_props_dialog(self)#{'FINISHED'}


    def execute(self, context):
        
        Delete_Clip(self,context)

        return {'RUNNING_MODAL'}
    
#---------------------------------------------#           
#class SEQUENCER_MT_add(Operator):    
class LIVE_OT_Add_To_Scene(bpy.types.Operator):
    """Add Clip to Scene"""
    bl_label = "Add To Scene"
    bl_idname = "clipto.scene_operator"
    
    def execute(self, context):
        seq = context.area
        scene = context.scene
        live_tool = scene.live_tool
        wm = context.window_manager

    
        #Load images
        imagefrom = wm.clip_dir + wm.shot_enum
        p,d,f = next(os.walk(imagefrom))
        if f == None:
            return {'PASS_THROUGH'}

        load_into_scene(self, context, wm.clip_previews, clip=True, capture=False) 
        return {'FINISHED'}


#---------------------------------------------#
class LIVE_OT_Pic_To_Scene(bpy.types.Operator):
    """Add Image to Scene"""
    bl_label = "Pic To Scene"
    bl_idname = "pic_to.scene_operator"
    
    def execute(self, context):
        seq = context.area
        scene = context.scene
        live_tool = scene.live_tool
        wm = context.window_manager

#        #Load images
        load_into_scene(self, context, wm.clip_previews, clip=False, capture=False) 

        return {'FINISHED'}

#---------------------------------------------# 
classes = [LIVE_Properties, 
        LIVE_PT_main_panel, 
        LIVE_OT_camera, 
        LIVE_OT_Add_To_Scene,
        LIVE_OT_Pic_To_Scene,
        LIVE_OT_DeleteClip,
        ]
 
#---------------------------------------------# 
def register():

    WindowManager.clip_dir = StringProperty(
        name="Clip Location",
        subtype='DIR_PATH',
        default=default_path
    )


    WindowManager.shot_enum = EnumProperty(
        items=accum_enum,
        name= "Shots",
        description= "Shot list",

    )    

    WindowManager.clip_previews = EnumProperty(
        items=previews_images,
    )

    import bpy.utils.previews
    pcoll = bpy.utils.previews.new()
    pcoll.clip_dir = ""
    pcoll.clip_preview = ()

    preview_collections["main"] = pcoll
    
    for cls in classes:
        
        bpy.utils.register_class(cls)
        
        bpy.types.Scene.live_tool = bpy.props.PointerProperty(type= LIVE_Properties)
        bpy.context.window_manager['shot_enum'] = 1
    
#---------------------------------------------#        
def unregister():

    for cls in classes:
        bpy.utils.unregister_class(cls)
        del bpy.types.Scene.live_tool
    del WindowManager.shot_enum
    del WindowManager.clip_dir

    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear() 
    bpy.ops.outliner.orphans_purge()
#---------------------------------------------#
if __name__ == "__main__":
    register()    
    
